public class Student {
    // 변수는 선언위치에 따라서 지역, 전역(멤버)로 나뉜다.
    String  name ;
    char    gender ;   
}

