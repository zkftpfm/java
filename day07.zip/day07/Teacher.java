public class Teacher {
    
    // 전역변수 선언
    public String   name ;
    public double   height ;
    public int      age ;
    public String   bloodType ;
    public String   birthPlace ;
    public boolean  isMarriage ; 

    // 생성자 : Constructor 
    // like a method 
    // 반환타입 X , 메서드명은 클래스의 이름과 동일
    // 메서드처럼 직접적인 호출은 불가
    // 객체생성시 호출 가능 
    // 매개변수를 받지않는 생성자를 기본생성자(Default Construtor)
    
}
