public class EnumMain {
    public static void main(String[] args) {
        EnumApp division =  EnumApp.EMP ; 
        if(division == EnumApp.EMP) {
            System.out.println(division.getDivision());
        }
    }
}

