import siat.study.oop.domain.constructor.PersonVO;
import siat.study.oop.domain.constructor.ManagerVO;
import siat.study.oop.domain.constructor.StudentVO;
import siat.study.oop.domain.constructor.TeacherVO;

public class OopMain {
    /*
    OOP(Object Oriented Programming)
    - 은닉화
    - 상속
    - 다형성(타입, 매개변수, 메서드)
    - 추상화
    */
    public static void main(String[] args) {
        ////////// 생성자를 이용한 상속
        StudentVO stu = new StudentVO("박신형", "노량진", "2018"); 
        System.out.println( stu.perInfo() ) ;
        System.out.println( stu.stuInfo() ) ; 

        TeacherVO tea = new TeacherVO("임섭순", "서초구", "자바");
        System.out.println( tea.perInfo() ) ;
        System.out.println( tea.teaInfo() ) ; 

        ManagerVO emp = new ManagerVO("이진규", "서초구", "교육운영팀");
        System.out.println( emp.perInfo() ) ;
        System.out.println( emp.managerInfo() ) ; 
        ////////////////////////////////////////////////
        
        PersonVO stu01 = new StudentVO("박신형", "노량진", "2018"); 
        System.out.println( stu01.perInfo() ) ;
        System.out.println( ((StudentVO)stu01).stuInfo() ) ;

        PersonVO tea01 = new TeacherVO("임섭순", "서초구", "자바");
        PersonVO emp01 = new ManagerVO("이진규", "서초구", "교육운영팀");
        
        ///// 다형성을 사용하는 이유?
        System.out.println(">>>> 다형성");
        PersonVO [] perAry = new PersonVO[3]; 
        perAry[0] = stu ; 
        perAry[1] = tea ; 
        perAry[2] = emp ;  
        for(int idx=0 ; idx < perAry.length ; idx++) {
            PersonVO per = perAry[idx] ;  
            // instanceof 연산자 : 객체타입을 비교해주는 연산자 
            if(per instanceof StudentVO) {
               System.out.println( ((StudentVO)per).stuInfo() ) ;
            }
            if(per instanceof TeacherVO) {
                System.out.println( ((TeacherVO)per).teaInfo() ) ;
            }
            if(per instanceof ManagerVO) {
                System.out.println( ((ManagerVO)per).managerInfo() ) ;
            }
        }
    }
}